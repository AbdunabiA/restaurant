const form = document.getElementById('form')
const commentsBody = document.getElementById("comments-container");
let today = new Date();
const dd = String(today.getDate())
const mm = String(today.getMonth() + 1) //January is 0!
const yyyy = today.getFullYear();

today = `${mm}.${dd}.${yyyy}`

function openForm() {
    form.classList.remove('hidden')
}
function closeForm() {
    form.classList.add('hidden')
}
form.addEventListener(
  "click",
  (e) => {
    if (e.target.id == "form") {
      e.target.classList.add("hidden");
    }
  },
  true
);

function addComment(e){
    e.preventDefault
    const name = document.getElementById('name').value
    const comment = document.getElementById('comment').value
    commentsBody.innerHTML += `
        <div id="comments-body" class="rounded-md bg-white mt-5 p-2">
                    <div class="flex items-center space-x-5">
                        <h1 class="text-lg font-bold">${name}</h1>
                        <p class="opacity-50 text-sm">${today}</p>
                    </div>
                    <div class="flex items-end justify-between">
                        <p class="mt-3">
                            ${comment}
                        </p>
                        <button onclick="deleteComment(this)" class="relative bg-black rounded-md px-6 py-2 text-white group">
                        <span class="absolute rounded-l top-0 left-0 bg-orange-500 w-0 h-full group-hover:w-[50%] transition-color duration-300"></span>
                        <span class="absolute rounded-r top-0 right-0 bg-orange-500 w-0 h-full group-hover:w-[50%] transition-color duration-300"></span>
                        <span class="relative">Удалить</span>
                    </button>
                    </div>
                </div>
    `;
    closeForm()
}

function deleteComment(e) {
    const elem = e.parentElement.parentElement
    elem.parentNode.removeChild(elem);
}
