const slider1 = new Splide("#slider1", {
  type: "loop",
  // rewind : 'true',
  speed: 1500,
  gap: 20,
  // pagination : true,
  dragMinThreshold: {
    mouse: 0,
    touch: 10,
  },
  flickPower: 500,
  autoplay: true,
  interval: 5000,
  // pauseOnHover:true
  keyboard: true,
  slideFocus: true,
  // isNavigation : true
  // perPage: 4,
  // breakpoints: {
  // 	640: {
  // 		perPage: 2,
  // 	},
  // }
  // pagination: 'splide__pagination bg-black',
}).mount();


const slider2 = new Splide("#slider2", {
  type: "loop",
  // rewind : 'true',
  arrows: false,
  speed: 1500,
  gap: 10,
  // pagination : true,
  dragMinThreshold: {
    mouse: 0,
    touch: 10,
  },
  flickPower: 500,
  autoplay: true,
  interval: 5000,
  pauseOnHover: true,
  keyboard: true,
  slideFocus: true,
  // isNavigation : true,
  perPage: 3,
  perMove: 1,
  // breakpoints: {
  // 	640: {
  // 		perPage: 2,
  // 	},
  // }
  // pagination: 'splide__pagination bg-black',
}).mount();


const slider3 = new Splide("#slider3", {
  type: "loop",
  // rewind : 'true',
  arrows: false,
  speed: 1500,
  gap: 10,
  // pagination : true,
  dragMinThreshold: {
    mouse: 0,
    touch: 10,
  },
  flickPower: 500,
  autoplay: true,
  interval: 5000,
  pauseOnHover: true,
  keyboard: true,
  slideFocus: true,
  // isNavigation : true,
  perPage: 3,
  perMove: 1,
  // breakpoints: {
  // 	640: {
  // 		perPage: 2,
  // 	},
  // }
  // pagination: 'splide__pagination bg-black',
}).mount();
