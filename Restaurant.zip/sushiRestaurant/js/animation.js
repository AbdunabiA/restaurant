let tl = gsap.timeline();


tl.from("#header", { y: -200, duration: 1 });
tl.from("#logo",{x: -200, duration: 1}, '<')
tl.from("#korzina", { x: 220, duration: 1 }, "<");
tl.from("#slider1", {opacity: 0, scale: 0.1, duration: 1}, "<")
tl.from("#menu1", { x: -200, duration: 0.2 });
tl.from("#menu2", { x: -200, duration: 0.2 });
tl.from("#menu3", { x: -200, duration: 0.2 });
tl.from("#menu4", { x: -200, duration: 0.2 });
tl.from("#menu5", { x: -200, duration: 0.2 });
tl.from("#menu6", { x: -200, duration: 0.2 });
tl.from("#menu7", { x: -200, duration: 0.2 });
tl.from("#menu8", { x: -200, duration: 0.2 });
tl.from("#menu9", { x: -200, duration: 0.2 });
tl.from("#menu10", { x: -200, duration: 0.2 });

const time = gsap.timeline();

time.from("#korizna-product", {x:200, duration:0.5});


barba.init({
  transitions: [
    {
      name: "opacity-transition",
      leave(data) {
        return gsap.to(data.current.container, {
          x:1500,
          opacity: 0,
          duration: 1,
        });
      },
      enter(data) {
        return gsap.from(data.next.container, {
          x: 1500,
        });
      },
    },
  ],
});