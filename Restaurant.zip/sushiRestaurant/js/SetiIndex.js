const xochuButton = document.getElementById("xochu");
const korzina = document.getElementById("korzina");
const korzina1 = document.getElementById("korzina1");
const korzinaProducts = document.getElementById("products");
const korzinaProducts1 = document.getElementById("products1");
const form = document.getElementById("form");
const allPrices = document.getElementById("allPrices");
const allPrices1 = document.getElementById("allPrices1");
const productsList = document.getElementById("pc-body").children[0].children[1].children;
const productsList1 = document.getElementById("mobile-version").children[2].children
const fillterValue = document.getElementById('sort')
const productsContainer = document.getElementById('products-container')
const mobileKorzina = document.getElementById("korzina1-container");
const productsListCopy = [...productsList]



function openKorzina() {
  mobileKorzina.classList.remove('hidden')
}
function closeBasket() {
  mobileKorzina.classList.add("hidden");
}

function search(e) {
  for (let i of productsList) {
    if (
      !i.children[1].children[0].innerText
        .toLowerCase()
        .includes(e.value.toLowerCase())
    ) {
      i.classList.add("hidden");
    } else {
      i.classList.remove("hidden");
    }
  }
    for (let i of productsList1) {
      if (
        !i.children[1].children[0].innerText
          .toLowerCase()
          .includes(e.value.toLowerCase())
      ) {
        i.classList.add("hidden");
      } else {
        i.classList.remove("hidden");
      }
    }
}

function fillter(e) {
  let products = [];
  let names = []
  let weights = []
  let slices = []
  let prices = [] 
  let regexp = /\S+/;
  let regex = /\S+/g;
  for (let i of productsListCopy) {
    products.push({
      name: i.children[1].children[0].innerText,
      weight: Number(i.children[1].children[1].innerText.match(regexp)),
      slices: Number(i.children[1].children[1].innerText.match(regex)[2]),
      price: Number(
        i.children[1].children[2].children[0].innerText.match(regexp)
      ),
      img: i.children[0].children[0].outerHTML,
    });
  }
  let productsCopy = products
  
  for(let i of products) {
    names.push(i.name)
    weights.push(i.weight)
    slices.push(i.slices)
    prices.push(i.price)
  }
  
  if (e.value == "default") {
    productsContainer.textContent = "";
    for (let i = 0; i < products.length; i++) {
      productsContainer.innerHTML += `<div id='korizna-product' class="card-body bg-gradient-to-l from-[#EC9F05] to-[#FF4E00] p-2 rounded hover:scale-95 hover:shadow-md hover:shadow-black hover:rounded-lg hover:bg-gradient-to-r from-[#EC9F05] to-[#FF4E00] cursor-pointer transition-all duration-500">
                        <div class="imgage-container">
                            ${products[i].img}
                        </div>
                        <div class="info">
                            <p id="product-name" class="font-bold text-white my-2">
                                ${products[i].name}
                            </p>
                            <p class="text-white mb-4">
                                ${products[i].weight} грамм ${products[i].slices} кусочек
                            </p>
                                        <div class="flex items-center justify-around py-2 border border-transparent border-t-black">
                                            <p id="product-price" class="font-bold mr-1">${products[i].price} СОМ</p>
                                            <button onclick="takeCard(this)" class="relative inline-block text-lg group">
    <span class="relative z-10 block px-5 py- overflow-hidden font-medium leading-tight text-gray-800 transition-colors duration-300 ease-out border-2 border-gray-900 rounded-lg group-hover:text-white">
    <span class="absolute inset-0 w-full h-full px-5 py- rounded-lg bg-gray-50"></span>
    <span class="absolute left-0 w-48 h-48 -ml-2 transition-all duration-300 origin-top-right -rotate-90 -translate-x-full translate-y-12 bg-gray-900 group-hover:-rotate-180 ease"></span>
    <span class="relative font-bold">Хочу</span>
    </span>
    <span class="absolute bottom-0 right-0 w-full h-6 -mb-1 -mr-1 transition-all duration-200 ease-linear bg-gray-900 rounded-lg group-hover:mb-0 group-hover:mr-0" data-rounded="rounded-lg"></span>
    </button>
                                        </div>
                                    </div>
                                </div>`;
    }
  } else if (e.value == "name") {
    productsContainer.textContent = "";
    for (let i = 0; i < names.length; i++) {
      for (let j = 0; j < products.length; j++) {
        if (names.sort()[i] == products[j].name) {
          productsContainer.innerHTML += `<div class="card-body bg-gradient-to-l from-[#EC9F05] to-[#FF4E00] p-2 rounded hover:scale-95 hover:shadow-md hover:shadow-black hover:rounded-lg hover:bg-gradient-to-r from-[#EC9F05] to-[#FF4E00] cursor-pointer transition-all duration-500">
                        <div class="imgage-container">
                            ${products[j].img}
                        </div>
                        <div class="info">
                            <p id="product-name" class="font-bold text-white my-2">
                                ${products[j].name}
                            </p>
                            <p class="text-white mb-4">
                                ${products[j].weight} грамм ${products[j].slices} кусочек
                            </p>
                                        <div class="flex items-center justify-around py-2 border border-transparent border-t-black">
                                            <p id="product-price" class="font-bold mr-1">${products[j].price} СОМ</p>
                                            <button onclick="takeCard(this)" class="relative inline-block text-lg group">
    <span class="relative z-10 block px-5 py- overflow-hidden font-medium leading-tight text-gray-800 transition-colors duration-300 ease-out border-2 border-gray-900 rounded-lg group-hover:text-white">
    <span class="absolute inset-0 w-full h-full px-5 py- rounded-lg bg-gray-50"></span>
    <span class="absolute left-0 w-48 h-48 -ml-2 transition-all duration-300 origin-top-right -rotate-90 -translate-x-full translate-y-12 bg-gray-900 group-hover:-rotate-180 ease"></span>
    <span class="relative font-bold">Хочу</span>
    </span>
    <span class="absolute bottom-0 right-0 w-full h-6 -mb-1 -mr-1 transition-all duration-200 ease-linear bg-gray-900 rounded-lg group-hover:mb-0 group-hover:mr-0" data-rounded="rounded-lg"></span>
    </button>
                                        </div>
                                    </div>
                                </div>`;
        }
      }
    }
  } else if (e.value == "price-cheap") {
    productsContainer.textContent = "";
    let addedNames = [];
    for (let i = 0; i < prices.length; i++) {
      for (let j = 0; j < products.length; j++) {
        if (
          prices.sort()[i] == products[j].price &&
          !addedNames.includes(products[j].name)
        ) {
          addedNames.push(products[j].name);
          productsContainer.innerHTML += `<div class="card-body bg-gradient-to-l from-[#EC9F05] to-[#FF4E00] p-2 rounded hover:scale-95 hover:shadow-md hover:shadow-black hover:rounded-lg hover:bg-gradient-to-r from-[#EC9F05] to-[#FF4E00] cursor-pointer transition-all duration-500">
                        <div class="imgage-container">
                            ${products[j].img}
                        </div>
                        <div class="info">
                            <p id="product-name" class="font-bold text-white my-2">
                                ${products[j].name}
                            </p>
                            <p class="text-white mb-4">
                                ${products[j].weight} грамм ${products[j].slices} кусочек
                            </p>
                                        <div class="flex items-center justify-around py-2 border border-transparent border-t-black">
                                            <p id="product-price" class="font-bold mr-1">${products[j].price} СОМ</p>
                                            <button onclick="takeCard(this)" class="relative inline-block text-lg group">
    <span class="relative z-10 block px-5 py- overflow-hidden font-medium leading-tight text-gray-800 transition-colors duration-300 ease-out border-2 border-gray-900 rounded-lg group-hover:text-white">
    <span class="absolute inset-0 w-full h-full px-5 py- rounded-lg bg-gray-50"></span>
    <span class="absolute left-0 w-48 h-48 -ml-2 transition-all duration-300 origin-top-right -rotate-90 -translate-x-full translate-y-12 bg-gray-900 group-hover:-rotate-180 ease"></span>
    <span class="relative font-bold">Хочу</span>
    </span>
    <span class="absolute bottom-0 right-0 w-full h-6 -mb-1 -mr-1 transition-all duration-200 ease-linear bg-gray-900 rounded-lg group-hover:mb-0 group-hover:mr-0" data-rounded="rounded-lg"></span>
    </button>
                                        </div>
                                    </div>
                                </div>`;
        }
      }
    }
  } else if (e.value == "price-expensive") {
    productsContainer.textContent = "";
    let addedNames = [];
    for (let i = 0; i < prices.length; i++) {
      for (let j = 0; j < products.length; j++) {
        if (
          prices.sort((a, b) => b - a)[i] == products[j].price &&
          !addedNames.includes(products[j].name)
        ) {
          addedNames.push(products[j].name);
          productsContainer.innerHTML += `<div class="card-body bg-gradient-to-l from-[#EC9F05] to-[#FF4E00] p-2 rounded hover:scale-95 hover:shadow-md hover:shadow-black hover:rounded-lg hover:bg-gradient-to-r from-[#EC9F05] to-[#FF4E00] cursor-pointer transition-all duration-500">
                        <div class="imgage-container">
                            ${products[j].img}
                        </div>
                        <div class="info">
                            <p id="product-name" class="font-bold text-white my-2">
                                ${products[j].name}
                            </p>
                            <p class="text-white mb-4">
                                ${products[j].weight} грамм ${products[j].slices} кусочек
                            </p>
                                        <div class="flex items-center justify-around py-2 border border-transparent border-t-black">
                                            <p id="product-price" class="font-bold mr-1">${products[j].price} СОМ</p>
                                            <button onclick="takeCard(this)" class="relative inline-block text-lg group">
    <span class="relative z-10 block px-5 py- overflow-hidden font-medium leading-tight text-gray-800 transition-colors duration-300 ease-out border-2 border-gray-900 rounded-lg group-hover:text-white">
    <span class="absolute inset-0 w-full h-full px-5 py- rounded-lg bg-gray-50"></span>
    <span class="absolute left-0 w-48 h-48 -ml-2 transition-all duration-300 origin-top-right -rotate-90 -translate-x-full translate-y-12 bg-gray-900 group-hover:-rotate-180 ease"></span>
    <span class="relative font-bold">Хочу</span>
    </span>
    <span class="absolute bottom-0 right-0 w-full h-6 -mb-1 -mr-1 transition-all duration-200 ease-linear bg-gray-900 rounded-lg group-hover:mb-0 group-hover:mr-0" data-rounded="rounded-lg"></span>
    </button>
                                        </div>
                                    </div>
                                </div>`;
        }
      }
    }
  } else if (e.value == "slices") {
    productsContainer.textContent = "";
    let addedNames = [];
    for (let i = 0; i < slices.length; i++) {
      for (let j = 0; j < products.length; j++) {
        if (
          slices.sort()[i] == products[j].slices &&
          !addedNames.includes(products[j].name)
        ) {
          addedNames.push(products[j].name);
          productsContainer.innerHTML += `<div class="card-body bg-gradient-to-l from-[#EC9F05] to-[#FF4E00] p-2 rounded hover:scale-95 hover:shadow-md hover:shadow-black hover:rounded-lg hover:bg-gradient-to-r from-[#EC9F05] to-[#FF4E00] cursor-pointer transition-all duration-500">
                        <div class="imgage-container">
                            ${products[j].img}
                        </div>
                        <div class="info">
                            <p id="product-name" class="font-bold text-white my-2">
                                ${products[j].name}
                            </p>
                            <p class="text-white mb-4">
                                ${products[j].weight} грамм ${products[j].slices} кусочек
                            </p>
                                        <div class="flex items-center justify-around py-2 border border-transparent border-t-black">
                                            <p id="product-price" class="font-bold mr-1">${products[j].price} СОМ</p>
                                            <button onclick="takeCard(this)" class="relative inline-block text-lg group">
    <span class="relative z-10 block px-5 py- overflow-hidden font-medium leading-tight text-gray-800 transition-colors duration-300 ease-out border-2 border-gray-900 rounded-lg group-hover:text-white">
    <span class="absolute inset-0 w-full h-full px-5 py- rounded-lg bg-gray-50"></span>
    <span class="absolute left-0 w-48 h-48 -ml-2 transition-all duration-300 origin-top-right -rotate-90 -translate-x-full translate-y-12 bg-gray-900 group-hover:-rotate-180 ease"></span>
    <span class="relative font-bold">Хочу</span>
    </span>
    <span class="absolute bottom-0 right-0 w-full h-6 -mb-1 -mr-1 transition-all duration-200 ease-linear bg-gray-900 rounded-lg group-hover:mb-0 group-hover:mr-0" data-rounded="rounded-lg"></span>
    </button>
                                        </div>
                                    </div>
                                </div>`;
        }
      }
    }
  } else if (e.value == "weight") {
    productsContainer.textContent = "";
    let addedNames = [];
    for (let i = 0; i < weights.length; i++) {
      for (let j = 0; j < products.length; j++) {
        if (
          weights.sort()[i] == products[j].weight &&
          !addedNames.includes(products[j].name)
        ) {
          addedNames.push(products[j].name);
          productsContainer.innerHTML += `<div class="card-body bg-gradient-to-l from-[#EC9F05] to-[#FF4E00] p-2 rounded hover:scale-95 hover:shadow-md hover:shadow-black hover:rounded-lg hover:bg-gradient-to-r from-[#EC9F05] to-[#FF4E00] cursor-pointer transition-all duration-500">
                        <div class="imgage-container">
                            ${products[j].img}
                        </div>
                        <div class="info">
                            <p id="product-name" class="font-bold text-white my-2">
                                ${products[j].name}
                            </p>
                            <p class="text-white mb-4">
                                ${products[j].weight} грамм ${products[j].slices} кусочек
                            </p>
                                        <div class="flex items-center justify-around py-2 border border-transparent border-t-black">
                                            <p id="product-price" class="font-bold mr-1">${products[j].price} СОМ</p>
                                            <button onclick="takeCard(this)" class="relative inline-block text-lg group">
    <span class="relative z-10 block px-5 py- overflow-hidden font-medium leading-tight text-gray-800 transition-colors duration-300 ease-out border-2 border-gray-900 rounded-lg group-hover:text-white">
    <span class="absolute inset-0 w-full h-full px-5 py- rounded-lg bg-gray-50"></span>
    <span class="absolute left-0 w-48 h-48 -ml-2 transition-all duration-300 origin-top-right -rotate-90 -translate-x-full translate-y-12 bg-gray-900 group-hover:-rotate-180 ease"></span>
    <span class="relative font-bold">Хочу</span>
    </span>
    <span class="absolute bottom-0 right-0 w-full h-6 -mb-1 -mr-1 transition-all duration-200 ease-linear bg-gray-900 rounded-lg group-hover:mb-0 group-hover:mr-0" data-rounded="rounded-lg"></span>
    </button>
                                        </div>
                                    </div>
                                </div>`;
        }
      }
    }
  }
    //   console.log(prices.sort((a,b) => a-b));
    console.log(products);
}




function increase(e) {
  const regexp = /\S+/;
  const count = e.previousElementSibling;
  const price = e.parentElement.nextElementSibling;
  const containerDiv = e.parentElement.parentElement.parentElement.parentElement
  const prodName =
    e.parentElement.parentElement.parentElement.firstElementChild
      .lastElementChild.textContent;
  const collection1 = korzinaProducts1.children;
  const collection = korzinaProducts.children;
  let num = Number(count.textContent);
  let prodPrice = Number(price.textContent.match(regexp));
  price.innerHTML = `${prodPrice + prodPrice / num} СОМ`;
  if(containerDiv.id == 'products') {
    for (let i = 0; i < collection1.length; i++) {
      if(collection1[i].children[0].children[1].textContent == prodName){
        let num = Number(
          collection1[i].children[1].children[0].children[1].textContent
        );
        collection1[i].children[1].children[0].children[1].textContent = `${num + 1}`
        collection1[i].children[1].children[1].innerHTML = `${
          prodPrice + prodPrice / num
        } СОМ`;
      }
    }
  }
  if (containerDiv.id == "products1") {
    for (let i = 0; i < collection.length; i++) {
      if (collection[i].children[0].children[1].textContent == prodName) {
        let num = Number(
          collection[i].children[1].children[0].children[1].textContent
        );
        collection[i].children[1].children[0].children[1].textContent = `${
          num + 1
        }`;
        collection[i].children[1].children[1].innerHTML = `${
          prodPrice + prodPrice / num
        } СОМ`;
      }
    }
  }
  num += 1;
  count.innerHTML = `${num}`;
  countAllPrices();
}
function decrease(e) {
  const regexp = /\S+/;
  const count = e.nextElementSibling;
  const price = e.parentElement.nextElementSibling;
  const containerDiv =
    e.parentElement.parentElement.parentElement.parentElement;
  const prodName =
    e.parentElement.parentElement.parentElement.firstElementChild
      .lastElementChild.textContent;
  const collection1 = korzinaProducts1.children;
  const collection = korzinaProducts.children;
  let num = Number(count.textContent);
  let prodPrice = Number(price.textContent.match(regexp));
  if(num > 1){
    price.innerHTML = `${prodPrice - prodPrice / num} СОМ`;
    if (containerDiv.id == "products") {
      for (let i = 0; i < collection1.length; i++) {
        if (collection1[i].children[0].children[1].textContent == prodName) {
          let num = Number(
            collection1[i].children[1].children[0].children[1].textContent
          );
          collection1[i].children[1].children[0].children[1].textContent = `${
            num - 1
          }`;
          collection1[i].children[1].children[1].innerHTML = `${
            prodPrice - prodPrice / num
          } СОМ`;
        }
      }
    }
    if (containerDiv.id == "products1") {
      for (let i = 0; i < collection.length; i++) {
        if (collection[i].children[0].children[1].textContent == prodName) {
          let num = Number(
            collection[i].children[1].children[0].children[1].textContent
          );
          collection[i].children[1].children[0].children[1].textContent = `${
            num - 1
          }`;
          collection[i].children[1].children[1].innerHTML = `${
            prodPrice - prodPrice / num
          } СОМ`;
        }
      }
    }
    num -= 1;
    count.innerHTML = `${num}`;
  }
  countAllPrices();
}

function deleteProd(e) {
  const children = e.parentElement.parentElement.childElementCount;
  if (children == 1) {
    korzinaProducts.nextElementSibling.nextElementSibling.lastElementChild.textContent =
      "Бесплатная доставка от 800 СОМ";
    korzinaProducts.previousElementSibling.textContent =
      "Добавьте же скорее что-нибудь!";
    korzinaProducts.previousElementSibling.classList.remove("hidden");
    korzinaProducts.previousElementSibling.previousElementSibling.textContent =
      "Ваша корзина пуста.";
    korzinaProducts1.nextElementSibling.nextElementSibling.lastElementChild.textContent =
      "Бесплатная доставка от 800 СОМ";
    korzinaProducts1.previousElementSibling.textContent =
      "Добавьте же скорее что-нибудь!";
    korzinaProducts1.previousElementSibling.classList.remove("hidden");
    korzinaProducts1.previousElementSibling.previousElementSibling.firstElementChild.textContent =
      "Ваша корзина пуста.";
    allPrices.classList.add("hidden");
    allPrices1.classList.add("hidden");
  }
  const elem = e.parentElement;
  const containerDiv = e.parentElement.parentElement
  const prodName = e.parentElement.firstElementChild.lastElementChild.textContent
  const collection1 = korzinaProducts1.children;
  const collection = korzinaProducts.children;
  if (containerDiv.id == 'products') {
    for (let i = 0; i < collection1.length; i++) {
      if(collection1[i].children[0].children[1].textContent == prodName){
        collection1[i].parentNode.removeChild(collection1[i]);
      }
    }
  }
  if (containerDiv.id == "products1") {
    for (let i = 0; i < collection.length; i++) {
      if (collection[i].children[0].children[1].textContent == prodName) {
        collection[i].parentNode.removeChild(collection[i]);
      }
    }
  }
  elem.parentNode.removeChild(elem);
  countAllPrices();
  // e.parentElement.textContent = ''
}

function countAllPrices() {
  const collection = korzinaProducts.children;
  const collection1 = korzinaProducts1.children;
  let regexp = /\S+/;
  let prodPrice = 0;
  let prodPrice1 = 0;
  for (let i = 0; i < collection.length; i++) {
    prodPrice += Number(
      collection[i].children[1].children[1].childNodes[0].data.match(regexp)
    );
  }
  for (let i = 0; i < collection1.length; i++) {
    prodPrice1 += Number(
      collection1[i].children[1].children[1].childNodes[0].data.match(regexp)
    );
  }
  allPrices.innerHTML = `Всего: ${prodPrice} СОМ`;
  allPrices1.innerHTML = `Всего: ${prodPrice} СОМ`;
  return `Всего: ${prodPrice} СОМ`;
}

function takeCard(e) {
  const card = e.parentElement.parentElement.parentElement;
  const img = card.querySelector("img");
  const name = card.querySelector("#product-name");
  const price = card.querySelector("#product-price");
  korzinaProducts.innerHTML += `
  <div class='transition-all duration-500'>
    <div class='flex items-center mt-2 '>
      <img class='w-[40%]' src='${img.src}'> 
      <p class='text-sm'>${name.textContent}</p>
    </div>
    <div class='flex items-center justify-around'> 
      <div class='flex space-x-2 items-center'>
        <button onclick='decrease(this)' class='w-5 rounded hover:bg-orange-500 text-2xl hover:text-white hover:font-bold transition-all duration-300'>-</button>
        <p id='product-count'>1</p>
        <button onclick='increase(this)' class='w-5 rounded hover:bg-orange-500 text-2xl hover:text-white hover:font-bold transition-all duration-300'>+</button>
      </div>  
      <p id='price'>${price.textContent}</p>
    </div>
    <button onclick='deleteProd(this)' class="w-full py-1 border border-orange-500 border-2 relative rounded group overflow-hidden font-medium bg-[#E5E5E5]  text-orange-500 inline-block">
      <span class="absolute top-0 left-0 flex w-full h-0 mb-0 transition-all duration-200 ease-out transform translate-y-0 bg-orange-500 group-hover:h-full opacity-90"></span>
      <span class="relative group-hover:text-white">Удалить</span>
    </button>  
  </div>
  `;
  korzinaProducts1.innerHTML += `
  <div class='transition-all duration-500 border-2 border-orange-500 rounded-lg p-2 mt-2'>
    <div class='grid grid-cols-2 mt-2 space-x-2 text-center'>
      <img class='w-[100%]' src='${img.src}'> 
      <p class='text-xl text-center mx-auto mt-[30%]'>${name.textContent}</p>
    </div>
    <div class='grid grid-cols-2 mt-2'> 
      <div class='flex items-center justify-evenly'>
        <button onclick='decrease(this)' class='w-5 rounded hover:bg-orange-500 text-2xl hover:text-white hover:font-bold transition-all duration-300'>-</button>
        <p id='product-count1'>1</p>
        <button onclick='increase(this)' class='w-5 rounded hover:bg-orange-500 text-2xl hover:text-white hover:font-bold transition-all duration-300'>+</button>
      </div>  
      <p id='price1'>${price.textContent}</p>
    </div>
    <button onclick='deleteProd(this)' class="w-full py-1 border border-orange-500 border-2 relative rounded group overflow-hidden font-medium bg-[#E5E5E5]  text-orange-500 inline-block">
      <span class="absolute top-0 left-0 flex w-full h-0 mb-0 transition-all duration-200 ease-out transform translate-y-0 bg-orange-500 group-hover:h-full opacity-90"></span>
      <span class="relative group-hover:text-white">Удалить</span>
    </button>  
  </div>
  `;
  countAllPrices();
  allPrices.classList.remove("hidden");
  allPrices1.classList.remove("hidden");
  korzinaProducts.nextElementSibling.nextElementSibling.lastElementChild.textContent =
    "Оформить заказ";
  korzinaProducts1.nextElementSibling.nextElementSibling.lastElementChild.textContent =
    "Оформить заказ";
  korzinaProducts.nextElementSibling.nextElementSibling.classList.add("py-2");
  korzinaProducts1.nextElementSibling.nextElementSibling.classList.add("py-2");
  korzinaProducts.parentElement.firstElementChild.textContent = `Корзина`;
  korzinaProducts1.parentElement.firstElementChild.firstElementChild.textContent = `Корзина`;
  korzinaProducts.previousElementSibling.classList.add("hidden");
  korzinaProducts1.previousElementSibling.classList.add("hidden");
}
function takeCardMobile(e) {
  const card = e.parentElement.parentElement.parentElement;
  const img = card.querySelector("img");
  const name = card.querySelector("#product-name");
  const price = card.querySelector("#product-price");
  korzinaProducts.innerHTML += `
  <div class='transition-all duration-500'>
    <div class='flex items-center mt-2 '>
      <img class='w-[40%]' src='${img.src}'> 
      <p class='text-sm'>${name.textContent}</p>
    </div>
    <div class='flex items-center justify-around'> 
      <div class='flex space-x-2 items-center'>
        <button onclick='decrease(this)' class='w-5 rounded hover:bg-orange-500 text-2xl hover:text-white hover:font-bold transition-all duration-300'>-</button>
        <p id='product-count'>1</p>
        <button onclick='increase(this)' class='w-5 rounded hover:bg-orange-500 text-2xl hover:text-white hover:font-bold transition-all duration-300'>+</button>
      </div>  
      <p id='price'>${price.textContent}</p>
    </div>
    <button onclick='deleteProd(this)' class="w-full py-1 border border-orange-500 border-2 relative rounded group overflow-hidden font-medium bg-[#E5E5E5]  text-orange-500 inline-block">
      <span class="absolute top-0 left-0 flex w-full h-0 mb-0 transition-all duration-200 ease-out transform translate-y-0 bg-orange-500 group-hover:h-full opacity-90"></span>
      <span class="relative group-hover:text-white">Удалить</span>
    </button>  
  </div>
  `;
  korzinaProducts1.innerHTML += `
  <div class='transition-all duration-500 border-2 border-orange-500 rounded-lg p-2 mt-2'>
    <div class='grid grid-cols-2 mt-2 space-x-2 text-center'>
      <img class='w-[100%]' src='${img.src}'> 
      <p class='text-xl text-center mx-auto mt-[30%]'>${name.textContent}</p>
    </div>
    <div class='grid grid-cols-2 mt-2'> 
      <div class='flex items-center justify-evenly'>
        <button onclick='decrease(this)' class='w-5 rounded hover:bg-orange-500 text-2xl hover:text-white hover:font-bold transition-all duration-300'>-</button>
        <p id='product-count1'>1</p>
        <button onclick='increase(this)' class='w-5 rounded hover:bg-orange-500 text-2xl hover:text-white hover:font-bold transition-all duration-300'>+</button>
      </div>  
      <p id='price1'>${price.textContent}</p>
    </div>
    <button onclick='deleteProd(this)' class="w-full py-1 border border-orange-500 border-2 relative rounded group overflow-hidden font-medium bg-[#E5E5E5]  text-orange-500 inline-block">
      <span class="absolute top-0 left-0 flex w-full h-0 mb-0 transition-all duration-200 ease-out transform translate-y-0 bg-orange-500 group-hover:h-full opacity-90"></span>
      <span class="relative group-hover:text-white">Удалить</span>
    </button>  
  </div>
  `;
  countAllPrices();
  allPrices.classList.remove("hidden");
  allPrices1.classList.remove("hidden");
  korzinaProducts.nextElementSibling.nextElementSibling.lastElementChild.textContent =
    "Оформить заказ";
  korzinaProducts1.nextElementSibling.nextElementSibling.lastElementChild.textContent =
    "Оформить заказ";
  korzinaProducts.nextElementSibling.nextElementSibling.classList.add("py-2");
  korzinaProducts1.nextElementSibling.nextElementSibling.classList.add("py-2");
  korzinaProducts.parentElement.firstElementChild.textContent = `Корзина`;
  korzinaProducts1.parentElement.firstElementChild.firstElementChild.textContent = `Корзина`;
  korzinaProducts.previousElementSibling.classList.add("hidden");
  korzinaProducts1.previousElementSibling.classList.add("hidden");
}


function kuryerom(e) {
  e.classList.add("bg-orange-500");
  e.classList.add("text-white");
  e.classList.add("border-orange-500");
  e.nextElementSibling.classList.remove("bg-orange-500");
  e.nextElementSibling.classList.remove("text-white");
  e.nextElementSibling.classList.remove("border-orange-500");
}

function samovivoz(e) {
  e.classList.add("bg-orange-500");
  e.classList.add("text-white");
  e.classList.add("border-orange-500");
  e.previousElementSibling.classList.remove("bg-orange-500");
  e.previousElementSibling.classList.remove("text-white");
  e.previousElementSibling.classList.remove("border-orange-500");
}

function increment(e) {
  const count = e.previousElementSibling;
  let num = Number(count.textContent);
  num += 1;
  count.textContent = num;
}

function decrement(e) {
  const count = e.nextElementSibling;
  let num = Number(count.textContent);
  if (num >= 1) {
    num -= 1;
  }
  count.textContent = num;
}

function hide(e) {
  form.classList.add("hidden");
}

function openForm(e) {
  if (e.textContent == "Оформить заказ") {
    form.classList.remove("hidden");
    form.children[0].children[1].children[1].children[17].textContent =
      countAllPrices();
    // console.log(form.children[0].children[1].children[1].children[17]);
  }
}

form.addEventListener('click', e => {
  if (e.target.id == 'form'){
    e.target.classList.add("hidden");
  }
  
},true)
