const novinki = document.getElementById('novinki')
const popular = document.getElementById('popular')
const xochuButton = document.getElementById('xochu')
const korzina = document.getElementById('korzina')
const korzinaProducts = document.getElementById('products')
const form = document.getElementById('form')
const allPrices = document.getElementById('allPrices')
const productsList = document.getElementById('pc-body').children[0].children[1]


novinki.addEventListener('click', () => {
  document.getElementById('slider2').classList.remove('hidden')
  document.getElementById("slider3").classList.add("hidden");
  novinki.classList.add('underline')
  novinki.classList.remove('opacity-50')
  popular.classList.remove('underline')
  popular.classList.add('opacity-50')
})

popular.addEventListener('click', () => {
  document.getElementById('slider3').classList.remove('hidden')
  document.getElementById("slider2").classList.add("hidden");
  novinki.classList.remove("underline");
  novinki.classList.add("opacity-50");
  popular.classList.add("underline");
  popular.classList.remove("opacity-50");
})

function increase(e) {
  const count = e.previousElementSibling
  const price = e.parentElement.nextElementSibling
  let num = Number(count.textContent);
  let regexp = /\S+/
  let prodPrice = Number(price.textContent.match(regexp))
  if(num == 1) {
    price.innerHTML = `${prodPrice + prodPrice} СОМ`;
  } else {
    price.innerHTML = `${prodPrice + (prodPrice / num)} СОМ`;
  }
  num += 1
  count.innerHTML = `${num}`
  countAllPrices();
}
function decrease(e) {
  const count = e.nextElementSibling;
  const price = e.parentElement.nextElementSibling;
  let num = Number(count.textContent);
  let regexp = /\S+/;
  let prodPrice = Number(price.textContent.match(regexp));
  if (num > 1){ 
    price.innerHTML = `${prodPrice - prodPrice / num} СОМ`;
    num -= 1;
    count.innerHTML = `${num}`;
  }
  countAllPrices()
}

function deleteProd(e) {
  const children = e.parentElement.parentElement.childElementCount;
  if(children == 1) {
    e.parentElement.parentElement.nextElementSibling.nextElementSibling.lastElementChild.textContent =
      "Бесплатная доставка от 800 СОМ";  
    e.parentElement.parentElement.previousElementSibling.textContent =
      "Добавьте же скорее что-нибудь!";
    e.parentElement.parentElement.previousElementSibling.classList.remove('hidden')
    e.parentElement.parentElement.previousElementSibling.previousElementSibling.textContent =
      "Ваша корзина пуста.";
    allPrices.classList.add("hidden");
  }
  const elem = e.parentElement
  elem.parentNode.removeChild(elem);
  countAllPrices();
  // e.parentElement.textContent = ''
}

function countAllPrices() {
  const collection = korzinaProducts.children;
  let regexp = /\S+/;
  let prodPrice = 0;
  for (let i = 0; i < collection.length; i++) {
    prodPrice += Number(
      collection[i].children[1].children[1].childNodes[0].data.match(regexp)
    );
  }
  allPrices.innerHTML = `Всего: ${prodPrice} СОМ`;
  return `Всего: ${prodPrice} СОМ`;
}

function takeCard(e) {
  const card = e.parentElement.parentElement.parentElement;
  const img = card.querySelector("img");
  const name = card.querySelector("#product-name");
  const price = card.querySelector("#product-price");
  korzinaProducts.innerHTML += `
  <div>
    <div class='flex items-center mt-2'>
      <img class='w-[40%]' src='${img.src}'> 
      <p class='text-sm'>${name.textContent}</p>
    </div>
    <div class='flex items-center justify-around'> 
      <div class='flex space-x-2 items-center'>
        <button onclick='decrease(this)' class='w-5 rounded hover:bg-orange-500 text-2xl hover:text-white hover:font-bold transition-all duration-300'>-</button>
        <p id='product-count'>1</p>
        <button onclick='increase(this)' class='w-5 rounded hover:bg-orange-500 text-2xl hover:text-white hover:font-bold transition-all duration-300'>+</button>
      </div>  
      <p id='price'>${price.textContent}</p>
    </div>
    <button onclick='deleteProd(this)' class="w-full py-1 border border-orange-500 border-2 relative rounded group overflow-hidden font-medium bg-[#E5E5E5]  text-orange-500 inline-block">
      <span class="absolute top-0 left-0 flex w-full h-0 mb-0 transition-all duration-200 ease-out transform translate-y-0 bg-orange-500 group-hover:h-full opacity-90"></span>
      <span class="relative group-hover:text-white">Удалить</span>
    </button>  
  </div>
  `;
  countAllPrices();
  allPrices.classList.remove('hidden')
  korzinaProducts.nextElementSibling.nextElementSibling.lastElementChild.textContent =
    "Оформить заказ";
  korzinaProducts.nextElementSibling.nextElementSibling.classList.add("py-2");
  korzinaProducts.parentElement.firstElementChild.textContent = `Корзина`;
  korzinaProducts.previousElementSibling.classList.add("hidden");
}
 function takeSlide(e) {
  const name = e.previousElementSibling.firstElementChild.firstElementChild.textContent
  const price = e.previousElementSibling.lastElementChild.lastElementChild.textContent
  let img = ''
  if (name == '"Саломон сет"') {
    img = `<img class='w-[40%]' src='images/salomonSet.png'>`;
  } else if(name == '"Филадельфия и лосось сет"') {
    img = `<img class='w-[40%]' src='images/filadelfiyaILososSet.png'>`;
  } else if(name == '"Самая большая Филадельфия"') {
    img = `<img class='w-[40%]' src='images/SamayaBolshayaFiladelfiya.png'>`;
  }
  korzinaProducts.innerHTML += `
  <div>
    <div class='flex items-center mt-2'>
      ${img} 
      <p class='text-sm'>${name}</p>
    </div>
    <div class='flex items-center justify-around'> 
      <div class='flex space-x-2 items-center'>
        <button onclick='decrease(this)' class='w-5 rounded hover:bg-orange-500 text-2xl hover:text-white hover:font-bold transition-all duration-300'>-</button>
        <p id='product-count'>1</p>
        <button onclick='increase(this)' class='w-5 rounded hover:bg-orange-500 text-2xl hover:text-white hover:font-bold transition-all duration-300'>+</button>
      </div>  
      <p id='price'>${price}</p>
    </div>
    <button onclick='deleteProd(this)' class="w-full py-1 border border-orange-500 border-2 relative rounded group overflow-hidden font-medium bg-[#E5E5E5]  text-orange-500 inline-block">
      <span class="absolute top-0 left-0 flex w-full h-0 mb-0 transition-all duration-200 ease-out transform translate-y-0 bg-orange-500 group-hover:h-full opacity-90"></span>
      <span class="relative group-hover:text-white">Удалить</span>
    </button>  
  </div>
  `;
  countAllPrices();
  allPrices.classList.remove("hidden");
  korzinaProducts.nextElementSibling.nextElementSibling.lastElementChild.textContent =
    "Оформить заказ";
  korzinaProducts.nextElementSibling.nextElementSibling.classList.add("py-2");
  korzinaProducts.parentElement.firstElementChild.textContent = `Корзина`;
  korzinaProducts.previousElementSibling.classList.add("hidden");
}


function kuryerom(e) {
  e.classList.add('bg-orange-500')
  e.classList.add("text-white");
  e.classList.add("border-orange-500");
  e.nextElementSibling.classList.remove('bg-orange-500')
  e.nextElementSibling.classList.remove("text-white");
  e.nextElementSibling.classList.remove("border-orange-500");
}

function samovivoz(e) {
  e.classList.add("bg-orange-500");
  e.classList.add("text-white");
  e.classList.add("border-orange-500");
  e.previousElementSibling.classList.remove("bg-orange-500");
  e.previousElementSibling.classList.remove("text-white");
  e.previousElementSibling.classList.remove("border-orange-500");
}

function increment(e) {
  const count = e.previousElementSibling
  let num = Number(count.textContent)
  num += 1
  count.textContent = num
}

function decrement(e) {
  const count = e.nextElementSibling;
  let num = Number(count.textContent);
  if(num >= 1) {
    num -= 1;
  }
  count.textContent = num;
}

function hide(e) {
 
  form.classList.add('hidden')
}

function openForm(e) {
  if(e.textContent == 'Оформить заказ') {
    form.classList.remove("hidden");
    form.children[0].children[1].children[1].children[17].textContent = countAllPrices()
  }
}





form.addEventListener(
  "click",
  (e) => {
    if (e.target.id == "form") {
      e.target.classList.add("hidden");
    }
  },
  true
);